money = int(input())

coins = money // 10
money %= 10

coins += money // 5
money %= 5

coins += money

print(coins)