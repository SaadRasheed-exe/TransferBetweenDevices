n = int(input())
segments = [[int(x) for x in input().split()] for _ in range(n)]

possibleMarkers = []
markers = []

for minx, maxx in segments:
    possibleMarkers.append(maxx)

while len(segments) > 0:
    removeSegments = []
    marker = min(possibleMarkers)
    for i, (minx, maxx) in enumerate(segments):
        if (marker >= minx) and (marker <= maxx):
            removeSegments.append([minx, maxx])
            possibleMarkers.remove(maxx)
    for idx in removeSegments:
        segments.remove(idx)
    
    markers.append(marker)


print(len(markers))
print(' '.join([str(x) for x in markers]))