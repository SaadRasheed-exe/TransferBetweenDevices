n = int(input())
prices = [int(x) for x in input().split()]
clicks = [int(x) for x in input().split()]

totalRevenue = 0
for i in range(n):
    highestPrice = 0
    mostClick = 0
    
    for price, click in zip(prices, clicks):
        
        if price > highestPrice:
            highestPrice = price
        if click > mostClick:
            mostClick = click
        
    prices.remove(highestPrice)
    clicks.remove(mostClick)

    totalRevenue += (highestPrice * mostClick)

print(totalRevenue)