n, m = [int(x) for x in input().split()]

def get_pisano_period(m):
    a, b = 0, 1
    for i in range(m * m):
        a, b = b, (a + b) % m
        if a == 0 and b == 1:
            return i + 1
    return None

period = get_pisano_period(m)

n = n % period

a = 0
b = 1

for i in range(n):
    a, b = b, a + b

print(a % m)