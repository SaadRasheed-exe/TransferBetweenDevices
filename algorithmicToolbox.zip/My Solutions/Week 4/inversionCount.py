def merge(arr1: list, arr2: list):
    
    arr1Len, arr2Len = len(arr1), len(arr2)
    i, j = 0, 0
    newArr = []
    invCount = 0

    while (i < arr1Len) and (j < arr2Len):
        
        if arr1[i] <= arr2[j]:
            newArr.append(arr1[i])
            i += 1

        else:
            newArr.append(arr2[j])
            j += 1
            invCount += arr1Len - i
    
    newArr += arr1[i:]
    newArr += arr2[j:]

    return newArr, invCount

def sortAndCount(arr: list):
    arrLen = len(arr)
    
    if arrLen < 2:
        return arr, 0
    
    mid = arrLen // 2
    arr1 = arr[:mid]
    arr2 = arr[mid:]

    arr1, invCount1 = sortAndCount(arr1)
    arr2, invCount2 = sortAndCount(arr2)
    sortedArr, invCount = merge(arr1, arr2)


    return sortedArr, invCount1 + invCount2 + invCount


n = int(input())
arr = [int(x) for x in input().split()]

sortedArr, inversions = sortAndCount(arr)

print(inversions)