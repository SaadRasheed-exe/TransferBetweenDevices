from random import choice

def randomizedQuickSort(arr: list):

    if len(arr) < 2:
        return arr
    
    m = choice(arr)
    smaller = []
    larger = []
    sameCount = 0

    for num in arr:
        
        if num == m:
            sameCount += 1
        elif num < m:
            smaller.append(num)
        else:
            larger.append(num)
    
    smaller = randomizedQuickSort(smaller)
    larger = randomizedQuickSort(larger)

    return smaller + [m]*sameCount + larger


n = int(input())
arr = [int(x) for x in input().split()]

sortedArr = randomizedQuickSort(arr)

print(' '.join([str(x) for x in sortedArr]))