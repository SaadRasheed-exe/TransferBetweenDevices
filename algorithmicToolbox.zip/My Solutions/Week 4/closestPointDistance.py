def distance(a, b):
    ax, ay = a
    bx, by = b
    return ((ax - bx)**2 + (ay - by)**2)**0.5

def findLeastDistance(points):
    
    if len(points) == 2:
        return distance(points[0], points[1])

    if len(points) == 0:
        return float('int')

    s1 = []
    s2 = []

    maxx = max(points)[0]
    minx = min(points)[0]
    mid = (maxx + minx) / 2

    for point in points:
        if point[0] <= mid:
            s1.append(point)
        else:
            s2.append(point)


    d1 = findLeastDistance(s1) if len(s1) != 1 else float('inf')
    d2 = findLeastDistance(s2) if len(s2) != 1 else float('inf')
    d = min(d1, d2)

    withinStrip = []
    for point in points:
        if distance(point, [mid, point[1]]) < d:
            withinStrip.append(point)

    withinStrip = sorted(withinStrip, key=lambda x: x[1])
    dbar = float('inf')
    for i in range(len(withinStrip)):
        for j in range(i + 1, i + 8):
            if j < len(withinStrip):
                dbar = min(dbar, distance(withinStrip[i], withinStrip[j]))

    return min(d, dbar)


n = int(input())

points = []
for _ in range(n):
    points.append([int(x) for x in input().split()])

print(findLeastDistance(points))