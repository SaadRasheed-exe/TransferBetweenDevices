def findScores(segments, points):

    scores = {}

    if len(segments) == 0:
        for point in points:
            scores[point] = 0
        return scores

    segmentMinx = segments[0][0]
    segmentMaxx = max(segments, key=lambda x: x[1])[1] 

    if len(segments) == 1:
        for point in points:
            if (point >= segmentMinx) and (point <= segmentMaxx):
                scores[point] = 1
            else:
                scores[point] = 0
        return scores

    remainingPoints = []

    for point in points:
        if (point >= segmentMinx) and (point <= segmentMaxx):
            remainingPoints.append(point)
    
    segmentsMid = len(segments) // 2
    segments1 = segments[:segmentsMid]
    segments2 = segments[segmentsMid:]

    scores1 = findScores(segments1, remainingPoints)
    scores2 = findScores(segments2, remainingPoints)


    for point in points:
        scores[point] = 0
        scores[point] += scores1[point] if point in scores1 else 0
        scores[point] += scores2[point] if point in scores2 else 0
    
    return scores


n, m = [int(x) for x in input().split()]

segments = []
for _ in range(n):
    segments.append([int(x) for x in input().split()])
segments = sorted(segments)

points = [int(x) for x in input().split()]

scores = findScores(segments, points)
finalScores = []
for point in points:
    finalScores.append(str(scores[point]))

print(' '.join(finalScores))