n = int(input())
arr = [int(x) for x in input().split()]

counts = {}

for num in arr:
    if num in counts:
        counts[num] += 1
    else:
        counts[num] = 1

for count in counts.values():
    if count > (n / 2):
        print(1)
        exit()

print(0)
