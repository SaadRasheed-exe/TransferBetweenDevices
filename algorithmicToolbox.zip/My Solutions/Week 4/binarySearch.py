def binarySearch(arr: list, element):
    arrLen = len(arr)
    left = 0
    right = arrLen - 1

    while left < right:
        mid = (left + right) // 2
        if arr[mid] == element:
            return mid
        elif element > arr[mid]:
            left = mid + 1
        else:
            right = mid - 1

        if (left == right) and arr[left] == element:
            return left

    return -1

n = int(input())
arr = [int(x) for x in input().split()]

n2 = int(input())
qs = [int(x) for x in input().split()]

idx = []
for q in qs:
    idx.append(str(binarySearch(arr, q)))

print(' '.join(idx))
    