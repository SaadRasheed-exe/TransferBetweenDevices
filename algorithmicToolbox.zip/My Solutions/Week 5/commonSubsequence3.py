lenA = int(input())
a = tuple(input().split())

lenB = int(input())
b = tuple(input().split())

lenC = int(input())
c = tuple(input().split())

mem = [[[-1 for _ in range(lenC + 1)] for _ in range(lenB + 1)] for _ in range(lenA + 1)]

def findSubsequence(seqA, seqB, seqC, m, n, q):
    
    if (m == 0) or (n == 0) or (q == 0):
        return 0

    elif mem[m][n][q] != -1:
        return mem[m][n][q]

    elif seqA[m - 1] == seqB[n - 1] == seqC[q - 1]:
        mem[m][n][q] = 1 + findSubsequence(seqA, seqB, seqC, m-1, n-1, q-1)
        return mem[m][n][q]

    else:
        mem[m][n][q] = max(
            findSubsequence(seqA, seqB, seqC, m, n, q-1),
            findSubsequence(seqA, seqB, seqC, m, n-1, q),
            findSubsequence(seqA, seqB, seqC, m-1, n, q),
            findSubsequence(seqA, seqB, seqC, m, n-1, q-1),
            findSubsequence(seqA, seqB, seqC, m-1, n, q-1),
            findSubsequence(seqA, seqB, seqC, m-1, n-1, q),
        )
        return mem[m][n][q]

print(findSubsequence(a, b, c, lenA, lenB, lenC))