from random import choices
from string import ascii_lowercase

def func(a, b):

    mat = []
    lenA, lenB = len(a), len(b)

    for i in range(lenA):
        mat.append([i])
        for j in range(1, lenB):
            if i == 0:
                mat[i].append(j)
            else:
                mat[i].append(0)

    for i in range(1, lenA):
        for j in range(1, lenB):
            mat[i][j] = min(mat[i][j - 1], mat[i - 1][j], mat[i - 1][j -  1])
            mat[i][j] += 1 if a[i] != b[j] else 0
    

