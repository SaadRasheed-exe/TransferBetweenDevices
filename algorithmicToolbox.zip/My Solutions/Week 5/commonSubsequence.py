lenA = int(input())
a = tuple(input().split())

lenB = int(input())
b = tuple(input().split())

mem = [[-1 for _ in range(lenB + 1)] for _ in range(lenA + 1)]


def findSubsequence(seqA, seqB, m, n):
    
    if (m == 0) or (n == 0):
        return 0
    
    elif mem[m][n] != -1:
        return mem[m][n]

    elif seqA[m - 1] == seqB[n - 1]:
        mem[m][n] = 1 + findSubsequence(seqA, seqB, m-1, n-1)
        return mem[m][n]

    else:
        mem[m][n] = max(
            findSubsequence(seqA, seqB, m-1, n), 
            findSubsequence(seqA, seqB, m, n-1)
        )
        return mem[m][n]

print(findSubsequence(a, b, lenA, lenB))