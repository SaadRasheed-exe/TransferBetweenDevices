minOps = {}
minOps[1] = [0, []]

n = int(input())
# n = 96234
ops = []

i = 0
while True:

    i += 1

    if i * 3 in minOps:
        minOps[i * 3][0] = min(minOps[i][0] + 1, minOps[i * 3][0])
        minOps[i * 3][1] = min(minOps[i][1] + [3], minOps[i * 3][1], key=len)
    else:
        minOps[i * 3] = [minOps[i][0] + 1, minOps[i][1] + [3]]


    if i * 2 in minOps:
        minOps[i * 2][0] = min(minOps[i][0] + 1, minOps[i * 2][0])
        minOps[i * 2][1] = min(minOps[i][1] + [2], minOps[i * 2][1], key=len)

    else:
        minOps[i * 2] = [minOps[i][0] + 1, minOps[i][1] + [2]]


    if i + 1 in minOps:
        minOps[i + 1][0] = min(minOps[i][0] + 1, minOps[i + 1][0])
        minOps[i + 1][1] = min(minOps[i][1] + [1], minOps[i + 1][1], key=len)
    else:
        minOps[i + 1] = [minOps[i][0] + 1, minOps[i][1] + [1]]

    if n == i:
        break

    

print(minOps[n][0])

seq = [1]
for op in minOps[n][1]:
    seq.append((seq[-1] * op) if op in [2, 3] else (seq[-1] + 1))

print(' '.join([str(x) for x in seq]))