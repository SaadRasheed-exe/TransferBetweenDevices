a = ' ' + input()
b = ' ' + input()

mat = []
lenA, lenB = len(a), len(b)

for i in range(lenA + 1):
    mat.append([i])
    for j in range(1, lenB + 1):
        if i == 0:
            mat[i].append(j)
        else:
            mat[i].append(0)

for i in range(1, lenA + 1):
    for j in range(1, lenB + 1):
        mat[i][j] = min(mat[i][j - 1], mat[i - 1][j], mat[i - 1][j -  1])
        mat[i][j] += 1 if a[i - 1] != b[j - 1] else 0

print(mat[-1][-1])