denominations = [1, 3, 4]
maxDen = max(denominations)

money = int(input())
changes = [0] * (money + 1)

for i in range(1, money + 1):
    possibilities = []
    for den in denominations:
        if i - den >= 0:
            possibilities.append(changes[i - den] + 1)
    changes[i] = min(possibilities)


print(changes[-1])
