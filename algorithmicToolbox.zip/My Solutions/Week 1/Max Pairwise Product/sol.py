count = int(input())

nums = [int(x) for x in input().split(' ')]

max1 = max(nums)
nums.remove(max1)
max2 = max(nums)

print(max1 * max2)