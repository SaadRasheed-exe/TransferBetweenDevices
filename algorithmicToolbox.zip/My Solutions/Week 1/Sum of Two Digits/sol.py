nums = [int(x) for x in input().split(' ')]
print(sum(nums))