n, W = [int(x) for x in input().split()]

compounds = [[int(x) for x in input().split()] for _ in range(n)]

def bestItem(compounds):
    bestRatio = 0
    bestRatioIdx = -1
    for i, (c, w) in enumerate(compounds):
        currentRatio = c / w
        if currentRatio > bestRatio:
            bestRatio = currentRatio
            bestRatioIdx = i

    return bestRatioIdx

totalValue = 0

while W > 0:
    bestItemIdx = bestItem(compounds)
    if bestItemIdx == -1:
        break
    
    c, w = compounds[bestItemIdx]
    if W >= w:
        W -= w
        totalValue += c
    else:
        totalValue += (c / w) * W
        W = 0


    compounds.pop(bestItemIdx)

print(totalValue)

