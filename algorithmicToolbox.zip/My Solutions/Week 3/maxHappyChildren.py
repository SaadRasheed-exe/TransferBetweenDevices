n = int(input())


distribution = []

for i in range(1, n + 1):
    if (n - i) > i:
        distribution.append(i)
        n -= i
    else:
        distribution.append(n)
        break

print(len(distribution))
print(' '.join([str(x) for x in distribution]))

