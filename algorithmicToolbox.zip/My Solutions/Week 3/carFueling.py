D = int(input())
M = int(input())
N = int(input())
STOPS = [int(x) for x in input().split()]


remainingMiles = M
refuels = 0
prevStop = 0

for i in range(N):
    currentStop = STOPS[i]
    if i < N - 1:
        nextStop = STOPS[i + 1]
    else:
        nextStop = D

    remainingMiles -= (currentStop - prevStop)
    nextStopDistance = nextStop - currentStop
    if nextStopDistance > M:
        refuels = -1
        break

    if remainingMiles < nextStopDistance:
        refuels += 1
        remainingMiles = M
    
    prevStop = currentStop

print(refuels)