n = int(input())
nums = [x for x in input().split()]

maxLen = len(max(nums, key=len))

paddedNums = []
for num in nums:
    paddedNums.append(num + f'{num[-1]}'*(maxLen-len(num)))

maxSalary = ''.join(sorted(nums, key=lambda x: paddedNums[nums.index(x)], reverse=True))

print(maxSalary)