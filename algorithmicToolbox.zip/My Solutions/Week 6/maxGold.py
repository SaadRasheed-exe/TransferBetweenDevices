W, n = [int(x) for x in input().split()]
gold = [int(x) for x in input().split()]


mem = {}

def maxGold(w: int, gold: list):

    if (w == 0) or (len(gold) == 0):
        return 0
    
    if w in mem:
        return mem[w]

    if gold[-1] <= w:
        mem[w] = max(maxGold(w - gold[-1], gold[:-1]) + gold[-1], maxGold(w, gold[:-1]))
    else:
        mem[w] = maxGold(w, gold[:-1])

    return mem[w]

print(maxGold(W, gold))