class operator:
    def add(x, y):
        return x + y
    
    def sub(x, y):
        return x - y

    def mul(x, y):
        return x * y

def max_value(expression):

    # Extract numbers and operators
    numbers = [int(x) for x in expression[::2]]
    operators = expression[1::2]

    n = len(numbers)

    # Initialize tables for maximum and minimum values
    max_val = [[float('-inf')] * n for _ in range(n)]
    min_val = [[float('inf')] * n for _ in range(n)]

    # Base case: single number
    for i in range(n):
        max_val[i][i] = numbers[i]
        min_val[i][i] = numbers[i]

    # Fill the tables
    for length in range(2, n + 1):  # subexpression lengths from 2 to n
        for i in range(n - length + 1):
            j = i + length - 1
            for k in range(i, j):
                operator_fn = {'+': operator.add, '-': operator.sub, '*': operator.mul}[operators[k]]
                
                a = max_val[i][k]
                b = max_val[k + 1][j]
                c = min_val[i][k]
                d = min_val[k + 1][j]

                max_val[i][j] = max(max_val[i][j], operator_fn(a, b), operator_fn(c, d))
                min_val[i][j] = min(min_val[i][j], operator_fn(a, d), operator_fn(c, b))
    
    return max_val[0][n-1]


exp = input()
print(max_value(exp))
