n = int(input())
arr = [int(x) for x in input().split()]

mem = {}

def partition3(arr: list, s1: int, s2: int, s3: int):
    
    key = (s1, s2, s3)

    if key in mem:
        return mem[key]
    
    if len(arr) == 0:
        return int(s1 == s2 == s3)

    possibilities = []

    if s1 - arr[-1] >= 0:
        possibilities.append(partition3(arr[:-1], s1 - arr[-1], s2, s3))
    
    if s2 - arr[-1] >= 0:
        possibilities.append(partition3(arr[:-1], s1, s2 - arr[-1], s3))
    
    if s3 - arr[-1] >= 0:
        possibilities.append(partition3(arr[:-1], s1, s2, s3 - arr[-1]))
    
    if len(possibilities) == 0:
        return 0
    
    mem[key] = max(possibilities)

    return mem[key]

total = sum(arr)
if total % 3:
    print(0)
else:
    div = total // 3
    print(partition3(arr, div, div, div))