exp = input()

ops = {
    '+': lambda x, y: x + y,
    '-': lambda x, y: x - y,
    '*': lambda x, y: x * y,
}

mem = {}


def maxVal(exp: str, maximise: bool = True, newExp: str = None):

    if (exp, maximise) in mem:
        return mem[(exp, maximise)]

    if len(exp) == 3:
        return eval(exp)

    vals = []

    # vals.append(ops[exp[-2]](maxVal(exp[:-2], maximise=maximise), int(exp[-1])))
    # vals.append(eval(exp))

    op1 = exp[-2]
    match op1:
        case '+':
            vals.append(maxVal(exp[:-2], maximise=maximise) + int(exp[-1]))
        case '-':
            vals.append(maxVal(exp[:-2], maximise=maximise) - int(exp[-1]))
        case '*':
            vals.append(maxVal(exp[:-2], maximise=maximise) * int(exp[-1]))

    op2 = exp[1]
    match op2:
        case '+':
            vals.append(int(exp[0]) + maxVal(exp[2:], maximise=maximise))
        case '-':
            vals.append(int(exp[0]) - maxVal(exp[2:], maximise=not maximise))
        case '*':
            vals.append(int(exp[0]) * maxVal(exp[2:], maximise=maximise))


    val = max(vals) if maximise else min(vals)
    # print(f"Val: {val}")
    # print(f"Expression: {exp}")
    # print("Maximizing" if maximise else "Minimizing")
    # print()
    
    mem[(exp, maximise)] = val

    return val


print(maxVal(exp, maximise=False))